res.write("thankyou for submitting");




var body="";
  req.on('data', function (chunk) {
    body += chunk;
  });
  req.on('end', function () {
    console.log('POSTed: ' + body);
    res.write(body);
	res.end();
	
  });
  
  
    