class Car {
  constructor(name, year) {
    this.name = name;
    this.year = year;
  }
}

const myCar = new Car("Ford", 2014);


res.write(myCar.year.toString());
res.write(myCar.name);


res.end();

