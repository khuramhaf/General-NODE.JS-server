const fs = require('fs');

var http = require('http');
var path = require('path')



http.createServer(function (req, res) {
	
	var requrl = req.url;
	
	if (req.url == '/'){
		
		let rawdata = fs.readFileSync('index.html');
		 res.writeHead(200, {'Content-Type': 'text/html'});
  res.write(rawdata);
  res.end();
	}
	
	
	else if (req.url == '/favicon.ico'){
		
res.writeHead(200, {'Content-Type': 'text/plain'});
  res.write('');
  res.end();
	}
  else {
	  var x = req.url;
	  let y = 0;
	  if (x.charAt(0)=="/"){
	   y = x.replace("/", "");}
	   else {
		   y = x;
	   }
	 var z = path.extname(y);
	console.log(x);
	console.log(y);
	 let rawdata = fs.readFileSync(y);
	 
	 
	 
	 if (z==".css"){
		 
		 res.writeHead(200, {'Content-Type': 'text/css'});
	 }
	else if (z==".jpg"){
		 
		 res.writeHead(200, {'Content-Type': 'image/jpeg'});
	 }
	  else {
	  res.writeHead(200, {'Content-Type': 'text/html'});
	  }
	  res.write(rawdata);
	  res.end();
  }
}).listen(8080);